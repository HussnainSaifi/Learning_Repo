output "file_name" {
  value = local_file.internship_note.filename
}

output "file_content" {
  value = local_file.internship_note.content
}