variable "intern_name" {
  description = "Name of the intern"
  type        = string
  default     = "DMT Intern"
}