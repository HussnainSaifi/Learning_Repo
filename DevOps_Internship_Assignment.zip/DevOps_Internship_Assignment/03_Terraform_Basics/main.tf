terraform {
  required_providers {
    local = {
      source = "hashicorp/local"
      version = "~> 2.5"
    }
  }
}

provider "local" {}

resource "local_file" "internship_note" {
  filename = "internship-note.txt"

  content = "This file was created by ${var.intern_name} using Terraform."
}