from flask import Flask

app = Flask(__name__)

@app.route("/")
def home():
    return """
    <h1>DMT Internship 2026 - DevOps Lab</h1>
    <p>This application is running inside a container.</p>
    """

@app.route("/health")
def health():
    return {"status": "healthy"}

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)