terraform {
  required_providers {
    kubernetes = {
      source  = "hashicorp/kubernetes"
      version = "~> 2.30"
    }
  }
}

provider "kubernetes" {
  config_path = "~/.kube/config"
}

resource "kubernetes_deployment" "nginx" {
  metadata {
    name = "terraform-nginx"
    labels = {
      app = "terraform-nginx"
    }
  }

  spec {
    replicas = 2

    selector {
      match_labels = {
        app = "terraform-nginx"
      }
    }

    template {
      metadata {
        labels = {
          app = "terraform-nginx"
        }
      }

      spec {
        container {
          image = "nginx:latest"
          name  = "nginx"

          port {
            container_port = 80
          }
        }
      }
    }
  }
}

resource "kubernetes_service" "nginx_service" {
  metadata {
    name = "terraform-nginx-service"
  }

  spec {
    selector = {
      app = "terraform-nginx"
    }

    port {
      port        = 80
      target_port = 80
      node_port   = 30081
    }

    type = "NodePort"
  }
}